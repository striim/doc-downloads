/***** insorders.c ******************************************
**                                                          *
** Generate order records in binary format                  *
** Usage insorders <recordcount>                            *
** Max recordcount 1000000                                  *
** Note                                                     *
**                                                          *
************************************************************/
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
/* Define some useful constants */
#define HIGH  1
#define MEDIUM 2
#define LOW 3
#define PRICE_TYPES 3
#define FILENAME2               "/Users/mahadevan/binary/test.bin"
#define MAX_LEN_CNAME           20
#define MAX_DIG_CNAME           10
#define NAMELEN                 20
#define MAX_ITEM_COUNT          200
#define EXPENSIVE_ITEM_PRICE    745.99
#define MEDIUM_ITEM_PRICE       215.99
#define LOW_ITEM_PRICE          34.79
 
/* Function prototypes */
int testdata(int numRecords);
double setPrice(int cid);
int main(int argc, char *argv[])
{
  int count = 1000;
  int ret = 1;
  /* just basic error checking for now is sufficient */
  
  
   printf(" Inserting %d Records\n", count);
  
  
  if ((ret = testdata(count)) !=0)
     printf("TestData Failed\n");
} /* End Main */
/* Start Function for test data generation */
int testdata(int numRecords)
{
  int i,nm1,nm2 = 0;
  
  /* Declare variables for random record creation \n")*/  
  int order_id=10000;
  int district_id=0;
  int warehouse_id = 100;
  char cname[numRecords][MAX_LEN_CNAME];  
  char PrefixName[NAMELEN]="John";
  char numRecStr[MAX_DIG_CNAME];
  int count_id=0;
  double price=0;
  /* time_t now; Just generate sysdate for now */
  bzero(numRecStr,MAX_DIG_CNAME);
  FILE *fptr_bin =fopen(FILENAME2, "w");
  if (fptr_bin==NULL) return -1;
   for (nm1=0; nm1 < numRecords; nm1++)
   {
      sprintf(numRecStr, " %d",nm1); 
      strcat(PrefixName,numRecStr); 
      strcpy(cname[nm1],PrefixName); 
      //printf("Generated Name is %s\n", cname[nm1]);
      /* Re-init to base root for name */
      strcpy(PrefixName, "John");
      /* Generate a random count of items between 0 and 20 */
      count_id = rand()%MAX_ITEM_COUNT;
      price = setPrice(count_id);
      
      printf("Price is %f\n",price);
      short cnamelen = strlen(cname[nm1]);
      /* Generate record with the following fields */
      fwrite((const void *) (&order_id), sizeof(int), 1, fptr_bin); order_id++;
      fwrite((const void *) (&district_id), sizeof(int), 1, fptr_bin); district_id++;
      fwrite((const void *) (&warehouse_id), sizeof(int), 1, fptr_bin); warehouse_id++;
      fwrite((const void *) (&cnamelen), sizeof(short), 1, fptr_bin); 
      fwrite((const void *) (cname[nm1]), sizeof(char), strlen(cname[nm1]), fptr_bin); 
      fwrite((const void *) (&count_id), sizeof(int), 1, fptr_bin); count_id++;
      fwrite((const void *) (&price), sizeof(double), 1, fptr_bin); 
  }
  fclose(fptr_bin);
  return 0;
}
/* Start setPrice */
  double setPrice(int cid)
  {
    short i;
    double price, total_price=0;
    
    i = rand()%PRICE_TYPES;
    switch (i) 
    {
      case(HIGH):
          price = EXPENSIVE_ITEM_PRICE;
      case(MEDIUM):
          price = MEDIUM_ITEM_PRICE;
      case(LOW):
          price = LOW_ITEM_PRICE;
     }
     total_price = cid*price;
     return total_price;
  } /* End setPrice */
​