#!/usr/bin/env node

const axios = require('axios');
const fs = require('fs');
const ab2str = require('arraybuffer-to-string')
const url = "http://stream.meetup.com/2/rsvps";
axios({
  method: 'get',
  url: url,
   responseType:'stream'
  })
.then(res => {  
  const stream = res.data;
    stream.on('data', (chunk /* chunk is an ArrayBuffer */) => {        
        try {
            const json = ab2str(chunk);
            console.log(json);
            const obj = JSON.parse(json);
            axios.post("http://localhost:60000", obj);
        } catch {}
    });
    stream.on('end', () => {
        console.log("END");
    });
})
.catch(err => () => {
    console.log("END")
    console.log(err);
});
